/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import java.util.Scanner;

public class ComputeAvg {

    public static void main(String args[]) {
 
     double puntuacion[] = new double[5];
     double suma = 0.0;
     double media = 0.0;
     Scanner keyboard = new Scanner(System.in);
        System.out.println("ingrese las calificaciones de cada una de las 5 pruebas: ");
        for(int i = 0 ; i< puntuacion.length;i++){
            puntuacion[i] = keyboard.nextInt();
        }
        for(int i = 0 ; i< puntuacion.length;i++){
            suma = suma + puntuacion[i];
            media = suma /5;
        }
        System.out.println("la media de las puntuaciones es: " + media);
    }

}
